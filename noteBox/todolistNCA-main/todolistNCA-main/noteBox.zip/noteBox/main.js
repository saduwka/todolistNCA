const inputNotes = document.querySelector("#input-text");
const saveBtn = document.querySelector("#save");
const noteArea = document.querySelector("#notes");
const deleteBtnShow = document.querySelector("#delete-show");

document.addEventListener("DOMContentLoaded", () => {
	const savedNotes = JSON.parse(localStorage.getItem("notes")) || [];
	savedNotes.forEach((note) => {
		addNoteToDOM(note);
	});
});

saveBtn.addEventListener("click", (event) => {
	event.preventDefault();

	const inputValue = inputNotes.value.trim();
	if (inputValue === "") return;

	addNoteToDOM(inputValue);
	saveNoteToStorage(inputValue);
	inputNotes.value = "";
});

function addNoteToDOM(noteText) {
	const newNote = document.createElement("li");
	const newNoteText = document.createElement("span");
	newNoteText.textContent = noteText;
	newNote.appendChild(newNoteText);

	const deleteBtn = document.createElement("button");
	deleteBtn.textContent = "х";
	deleteBtn.classList.add("delete-btn");
	deleteBtn.addEventListener("click", () => {
		newNote.remove();
		deleteNoteFromStorage(noteText);
	});

	const toggleStrikeBtn = document.createElement("button");
	toggleStrikeBtn.textContent = "✓";
	toggleStrikeBtn.classList.add("strike-btn");
	toggleStrikeBtn.addEventListener("click", () => {
		if (newNoteText.style.textDecoration === "line-through") {
			newNoteText.style.textDecoration = "none";
		} else {
			newNoteText.style.textDecoration = "line-through";
		}
	});

	newNote.appendChild(newNoteText);
	newNote.appendChild(toggleStrikeBtn);
	newNote.appendChild(deleteBtn);
	noteArea.appendChild(newNote);
}


function saveNoteToStorage(noteText) {
	const savedNotes = JSON.parse(localStorage.getItem("notes")) || [];
	savedNotes.push(noteText);
	localStorage.setItem("notes", JSON.stringify(savedNotes));
}

function deleteNoteFromStorage(noteText) {
	let savedNotes = JSON.parse(localStorage.getItem("notes")) || [];
	savedNotes = savedNotes.filter((note) => note !== noteText);
	localStorage.setItem("notes", JSON.stringify(savedNotes));
}

deleteBtnShow.addEventListener("click", (event) => {
	event.preventDefault();
	const deleteBtns = document.querySelectorAll(".delete-btn");
	const areDeleteButtonsVisible = Array.from(deleteBtns).some((btn) => btn.style.display === "inline-block");
	const displayStyle = areDeleteButtonsVisible ? "none" : "inline-block";
	deleteBtns.forEach((btn) => {
		btn.style.display = displayStyle;
	});
});